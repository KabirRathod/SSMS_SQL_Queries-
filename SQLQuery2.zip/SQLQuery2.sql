select * from emp_details;

create procedure run
as select * from emp_details
go;

insert into emp_details
(emp_ID,emp_name,department,city,salary)
values
(1001,'Kabir','Database','AHM',950000),
(2001,'Harsang','Design','PUN',860000),
(1002,'Dwij','Frontend','AHM',750000),
(3001,'Nikul','Backend','BNG',900000),
(1003,'Sandhya','Fullstack','AHM',1500000),
(3002,'Pranshu','Admin','BNG',660000),
(2002,'Sahil','AI/ML','PUN',950000),
(2003,'Hiren','Cloud','PUN',800000),
(3003,'Yash','Frontend','BNG',750000),
(1004,'Monic','Marketing','AHM',500000);


update emp_details 
set department='AI'
where emp_ID=2002;

update emp_details
set salary='1000000'
where emp_ID=1001;

exec run;

select * from emp_details
where City NOT IN ('BNG','PUN');

select*from emp_details
order by salary desc;

select AVG(salary)
from emp_details;

select *from emp_details
where salary like '10%' or salary like '15%';

select *from emp_details
where salary like '1[0-5]0%';

select *from emp_details
where salary between 600000 and 900000 
order by salary desc;

select city,count(*)
from emp_details
group by city ;


select city,count(*)
from emp_details
where salary>900000
group by city
having count(*)>1


select *from emp_details
where emp_name like '%a%';
